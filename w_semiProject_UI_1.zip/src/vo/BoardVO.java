package vo;

public class BoardVO { //占쌉쏙옙占쏙옙
	private int boardcode, boardno, boardhit, animalno; //占쌉쏙옙占쏙옙占쌘듸옙, 占쌉시뱄옙占쏙옙호, 占쏙옙회占쏙옙 占쏙옙占쏙옙占쏙옙球占싫�
	private int boardref, boardseq, boardlvl; // 占쏙옙占�(占쏙옙占쏙옙), 占쏙옙占�(占쏙옙蒡占쏙옙占�), 占쏙옙方占쏙옙占�(트占쏙옙占쌤곤옙)
	private String boardtitle, memid, boardcontent, boarddate; //占쏙옙占쏙옙, 회占쏙옙占쏙옙占싱듸옙(占쌜쇽옙占쏙옙), 占쏙옙占쏙옙, 占쌜쇽옙占쏙옙占쏙옙 
	private String boardip, boardnoname, boardnopwd; //占쌜쇽옙占쏙옙 ip, 占쏙옙회占쏙옙占싱몌옙, 占쏙옙회占쏙옙占쏙옙占�
	private String chooseType, inputVal; // 占쌕아놂옙占쏙옙 占쏙옙占쏙옙占싱울옙占쏙옙 占쏙옙占쏙옙...
	private int start, end;
	
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getEnd() {
		return end;
	}
	public void setEnd(int end) {
		this.end = end;
	}
	public String getChooseType() {
		return chooseType;
	}
	public void setChooseType(String chooseType) {
		this.chooseType = chooseType;
	}
	public String getInputVal() {
		return inputVal;
	}
	public void setInputVal(String inputVal) {
		this.inputVal = inputVal;
	}
	public int getBoardcode() {
		return boardcode;
	}
	public void setBoardcode(int boardcode) {
		this.boardcode = boardcode;
	}
	public int getBoardno() {
		return boardno;
	}
	public void setBoardno(int boardno) {
		this.boardno = boardno;
	}
	public int getBoardhit() {
		return boardhit;
	}
	public void setBoardhit(int boardhit) {
		this.boardhit = boardhit;
	}
	public int getAnimalno() {
		return animalno;
	}
	public void setAnimalno(int animalno) {
		this.animalno = animalno;
	}
	public int getBoardref() {
		return boardref;
	}
	public void setBoardref(int boardref) {
		this.boardref = boardref;
	}
	public int getBoardseq() {
		return boardseq;
	}
	public void setBoardseq(int boardseq) {
		this.boardseq = boardseq;
	}
	public int getBoardlvl() {
		return boardlvl;
	}
	public void setBoardlvl(int boardlvl) {
		this.boardlvl = boardlvl;
	}
	public String getBoardtitle() {
		return boardtitle;
	}
	public void setBoardtitle(String boardtitle) {
		this.boardtitle = boardtitle;
	}
	public String getMemid() {
		return memid;
	}
	public void setMemid(String memid) {
		this.memid = memid;
	}
	public String getBoardcontent() {
		return boardcontent;
	}
	public void setBoardcontent(String boardcontent) {
		this.boardcontent = boardcontent;
	}
	public String getBoarddate() {
		return boarddate;
	}
	public void setBoarddate(String boarddate) {
		this.boarddate = boarddate;
	}
	public String getBoardip() {
		return boardip;
	}
	public void setBoardip(String boardip) {
		this.boardip = boardip;
	}
	public String getBoardnoname() {
		return boardnoname;
	}
	public void setBoardnoname(String boardnoname) {
		this.boardnoname = boardnoname;
	}
	public String getBoardnopwd() {
		return boardnopwd;
	}
	public void setBoardnopwd(String boardnopwd) {
		this.boardnopwd = boardnopwd;
	}
	

}
