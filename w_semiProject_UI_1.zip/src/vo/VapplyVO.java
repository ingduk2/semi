package vo;

public class VapplyVO {//�����û
	private int  vapplyno, volunteerno; // �����û��ȣ, �����ȣ
	private String memid, vapplydate; // ȸ�����̵�, �����û��¥
	public int getVapplyno() {
		return vapplyno;
	}
	public void setVapplyno(int vapplyno) {
		this.vapplyno = vapplyno;
	}
	public int getVolunteerno() {
		return volunteerno;
	}
	public void setVolunteerno(int volunteerno) {
		this.volunteerno = volunteerno;
	}
	public String getMemid() {
		return memid;
	}
	public void setMemid(String memid) {
		this.memid = memid;
	}
	public String getVapplydate() {
		return vapplydate;
	}
	public void setVapplydate(String vapplydate) {
		this.vapplydate = vapplydate;
	}

}
