package vo;

public class z_VolunteerVO {
	private int volunteerno;
	private String volunteertitle, volunteerstart, volunteerend;
	public int getVolunteerno() {
		return volunteerno;
	}
	public void setVolunteerno(int volunteerno) {
		this.volunteerno = volunteerno;
	}
	public String getVolunteertitle() {
		return volunteertitle;
	}
	public void setVolunteertitle(String volunteertitle) {
		this.volunteertitle = volunteertitle;
	}
	public String getVolunteerstart() {
		return volunteerstart;
	}
	public void setVolunteerstart(String volunteerstart) {
		this.volunteerstart = volunteerstart;
	}
	public String getVolunteerend() {
		return volunteerend;
	}
	public void setVolunteerend(String volunteerend) {
		this.volunteerend = volunteerend;
	}
	
	
}
