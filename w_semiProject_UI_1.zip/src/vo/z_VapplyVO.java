package vo;

public class z_VapplyVO {
	private int vapplyno, memno, volunteerno; 
	private String vapplydate;
	public int getVapplyno() {
		return vapplyno;
	}
	public void setVapplyno(int vapplyno) {
		this.vapplyno = vapplyno;
	}
	public int getMemno() {
		return memno;
	}
	public void setMemno(int memno) {
		this.memno = memno;
	}
	public int getVolunteerno() {
		return volunteerno;
	}
	public void setVolunteerno(int volunteerno) {
		this.volunteerno = volunteerno;
	}
	public String getVapplydate() {
		return vapplydate;
	}
	public void setVapplydate(String vapplydate) {
		this.vapplydate = vapplydate;
	}
	
	
}
