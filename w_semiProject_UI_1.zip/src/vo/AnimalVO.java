package vo;

public class AnimalVO {//�������...
	private int animalno, animalage,animalweight; //������Ϲ�ȣ, ��������, ��������
	private String animalspecies, animalbreed, animalname; // �����з�(������), �����з�(ǰ��), �����̸�
	private String animalsex, animalsize, animalfeature; //��������, ���� ũ��з�, ����Ư¡,
	private String animalregion, animaldate, animalimg; // ����(�н�,�߰�), ��¥(�н�,�߰�), ����
	
	public int getAnimalno() {
		return animalno;
	}
	public void setAnimalno(int animalno) {
		this.animalno = animalno;
	}
	public int getAnimalage() {
		return animalage;
	}
	public void setAnimalage(int animalage) {
		this.animalage = animalage;
	}
	public int getAnimalweight() {
		return animalweight;
	}
	public void setAnimalweight(int animalweight) {
		this.animalweight = animalweight;
	}
	public String getAnimalspecies() {
		return animalspecies;
	}
	public void setAnimalspecies(String animalspecies) {
		this.animalspecies = animalspecies;
	}
	public String getAnimalbreed() {
		return animalbreed;
	}
	public void setAnimalbreed(String animalbreed) {
		this.animalbreed = animalbreed;
	}
	public String getAnimalname() {
		return animalname;
	}
	public void setAnimalname(String animalname) {
		this.animalname = animalname;
	}
	public String getAnimalsex() {
		return animalsex;
	}
	public void setAnimalsex(String animalsex) {
		this.animalsex = animalsex;
	}
	public String getAnimalsize() {
		return animalsize;
	}
	public void setAnimalsize(String animalsize) {
		this.animalsize = animalsize;
	}
	public String getAnimalfeature() {
		return animalfeature;
	}
	public void setAnimalfeature(String animalfeature) {
		this.animalfeature = animalfeature;
	}
	public String getAnimalregion() {
		return animalregion;
	}
	public void setAnimalregion(String animalregion) {
		this.animalregion = animalregion;
	}
	public String getAnimaldate() {
		return animaldate;
	}
	public void setAnimaldate(String animaldate) {
		this.animaldate = animaldate;
	}
	public String getAnimalimg() {
		return animalimg;
	}
	public void setAnimalimg(String animalimg) {
		this.animalimg = animalimg;
	}

}
